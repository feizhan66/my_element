<template>
  <div class="app-container">
    我是主页
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  filters: {
   
  },
  created() {
  },
  methods: {
   
  }
}
</script>
