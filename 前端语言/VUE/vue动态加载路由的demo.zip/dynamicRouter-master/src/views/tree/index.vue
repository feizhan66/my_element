<template>
  <div class="app-container">
    我是tree
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  filters: {
   
  },
  created() {
  },
  methods: {
   
  }
}
</script>
